﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cocktails07.Controllers
{
    class HttpWebRequest
    {
    }
}
